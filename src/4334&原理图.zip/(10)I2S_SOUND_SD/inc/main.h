#ifndef __MAIN_H
#define __MAIN_H

#include <stm32f4xx.h>
#include <stdio.h>
#include "stm32f4xx_conf.h"
#include "delay.h"
#include "usart.h"
#include "sdio_sd.h"
#include "ff.h"
#include "cs4334.h"
#include "wavplayer.h"

#endif


